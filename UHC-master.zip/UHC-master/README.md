# One of the best UHC cores in Minecraft: Pocket Edition!

While having many features, this core comes with many things such as:

	An API to add scenarios.
	A teaming system.
	An automatic timer.
	An arena to practice in before the UHC!
	

Make sure to follow @IrishPlugins on Twitter for updates!

Donations are welcome! Donate [here](https://paypal.me/IrishPacks)!
